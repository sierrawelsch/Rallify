from flaskext.mysql import MySQL

db = MySQL()